@extends('layouts.master')

@section('title')
    Documentation Page
@endsection

@section('content')
    <div class="row">
        <div class="col-sm-12">
            <img src="/img/ass2_ERdiagram.png" alt="Error to show the image" style="max-width:100%;"/>
        </div>
    </div>
@endsection('content')