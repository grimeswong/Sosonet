<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h2>User Profile Change Form</h2>
            <div class="panel panel-primary">
                <?php if(count($errors)> 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="panel-heading">Register</div>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="/user/<?php echo e(Auth::id()); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>    <!-- we use the method put that using the hidden method put -->
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">

                                <?php if($errors->has('name')): ?>
                                    <input id="name" type="text" class="form-control" name="fullname" value="<?php echo e(old('name')); ?>" required autofocus>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php else: ?>
                                    <input id="name" type="text" class="form-control" name="fullname" value="<?php echo e(Auth::user()->fullname); ?>" required autofocus>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">

                                <?php if($errors->has('email')): ?>
                                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php else: ?>
                                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(Auth::user()->email); ?>" required>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!--<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">-->
                        <!--    <label for="password" class="col-md-4 control-label">Password</label>-->

                        <!--    <div class="col-md-6">-->

                        <!--        <?php if($errors->has('password')): ?>-->
                        <!--            <input id="password" type="password" class="form-control" name="password" required>-->
                        <!--            <span class="help-block">-->
                        <!--                <strong><?php echo e($errors->first('password')); ?></strong>-->
                        <!--            </span>-->
                        <!--        <?php else: ?>-->
                        <!--            <input id="password" type="password" class="form-control" name="<?php echo e(Auth::user()->password); ?>" required>-->
                        <!--        <?php endif; ?>-->
                        <!--    </div>-->
                        <!--</div>-->

                        <!--<div class="form-group">-->
                        <!--    <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>-->

                        <!--    <div class="col-md-6">-->
                        <!--        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>-->
                        <!--    </div>-->
                        <!--</div>-->
                        
                        <div class="form-group<?php echo e($errors->has('DOB') ? ' has-error' : ''); ?>">
                            <label for="DOB" class="col-md-4 control-label">DOB</label>

                            <div class="col-md-6">

                                <?php if($errors->has('DOB')): ?>
                                    <input id="DOB" type="date" class="form-control" name="DOB" value="<?php echo e(old('DOB')); ?>" required>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('DOB')); ?></strong>
                                    </span>
                                <?php else: ?>
                                    <input id="DOB" type="date" class="form-control" name="DOB" value="<?php echo e(Auth::user()->DOB); ?>" required>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                            <label for="image" class="col-md-4 control-label">Image</label>

                            <div class="col-md-6">

                                <?php if($errors->has('image')): ?>
                                    <input id="image" type="file" class="form-control" name="image" value="<?php echo e(old('image')); ?>" required>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php else: ?>    
                                    <input id="image" type="file" class="form-control" name="image" value="<?php echo e(Auth::user()->image); ?>" required>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Confirm to change
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>