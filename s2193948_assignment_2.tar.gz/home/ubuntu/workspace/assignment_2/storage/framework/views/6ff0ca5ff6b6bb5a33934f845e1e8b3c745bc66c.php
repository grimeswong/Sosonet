<?php $__env->startSection('title'); ?>
    Friends Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <!-- User Friend Listing -->
    <div class="col-sm-offset-2 col-sm-8">
        <h2>Friendship Page</h2>
        <?php $__empty_1 = true; $__currentLoopData = $friendships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="panel panel-primary">
            <div class="panel-heading clearfix">
                <a href="<?php echo e(url("user/$friend->id")); ?>" class="username">
                    <img class="avatar" src= "/<?php echo e($friend->image); ?>" alt="Image's not available"></img>
                    <span><?php echo e($friend->fullname); ?></span>
                </a>
                <form method="post" action="/friend/<?php echo e($friend->id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>  <!-- we use the method delete that using the hidden method -->
                    <button class="btn btn-danger btn-margin pull-right" type="submit">Unfriend</button>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
            <h3 class="error-middle">Search Result: No user found</h3>
        <?php endif; ?>
        
    </div>  <!-- end post panel -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>