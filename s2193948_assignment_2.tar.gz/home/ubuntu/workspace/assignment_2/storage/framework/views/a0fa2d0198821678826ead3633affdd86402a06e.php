<?php $__env->startSection('title'); ?>
    Documentation Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <img src="/img/ass2_ERdiagram.png" alt="Error to show the image" style="max-width:100%;"/>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>