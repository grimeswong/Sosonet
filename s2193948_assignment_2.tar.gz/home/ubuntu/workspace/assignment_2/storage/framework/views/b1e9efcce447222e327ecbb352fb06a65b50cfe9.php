<?php $__env->startSection('title'); ?>
    View Comment Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
         <!-- Form -->
        <div class="col-sm-4 form-border">
            <form method="post" action="/comment">
                <?php echo e(csrf_field()); ?>

                <div class="name"><h2>Create Comment Form</h2></div>
                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                
                <?php if(Auth::check()): ?> <!-- make sure user has logged in to get user name -->
                <div class="form-group message"><label>Current User: <?php echo e(Auth::user()->fullname); ?></label><br>
                    <input type="hidden" name="user_id" value="<?php echo e($post->user_id); ?>">
                </div>
                <?php endif; ?>
                
                <div class="message"><label>Message: </label><br>
                <?php if(count($errors)>0): ?>
                    <textarea id="messagetextarea" name="message" rows="4" placeholder="Enter new message"><?php echo e(old('message')); ?></textarea><span class="alert"><?php echo e($errors->first('message')); ?></span>
                <?php else: ?>
                    <textarea id="messagetextarea" name="message" rows="4" placeholder="Enter new message"></textarea>
                <?php endif; ?>
                </div>
                <div class="message">
                    <button class="btn btn-warning" type="submit">Create new comment</button>
                </div>
            </form>
        </div>
         <!-- End Form -->    
         
        <div class="col-sm-8" >
            <h2>View Comment Page</h2>
            <div class="panel panel-primary">
                <div class="panel-heading clearfix">
                    <img class="avatar" src= "/<?php echo e($post->user->image); ?>" alt="Image is not available"></img>
                    <span class="username"><?php echo e($post->user->fullname); ?></span>
                    <h4><?php echo e($post->title); ?></h4>
                    <p><?php echo e($post->message); ?></p>
                </div>
                
                <div class="panel-body">
                    <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item clearfix">
                            <p><?php echo e($comment->user->fullname); ?></p>
                            <span><?php echo e($comment->message); ?></span>
                             <form method="POST" action="/comment/<?php echo e($comment->id); ?>"> <!-- Delete Button -->
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>  <!-- we use the method delete that using the hidden method -->
                            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                            <?php if(Auth::id() == $comment->user_id || Auth::id() == $post->user_id): ?>    <!-- allow post or comment creator to delete -->
                                <button class="btn btn-danger btn-margin pull-right" type="submit">Delete</button>
                            <?php endif; ?>    
                            </form>
                            <!--<a class="btn btn-danger pull-right" href="<?php echo e(url("delete_comment/$comment->comment_id")); ?>">Delete</a>-->
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h3 class="error-middle">no comment</h3>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <div align="center"><?php echo e($comments->links()); ?></div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>