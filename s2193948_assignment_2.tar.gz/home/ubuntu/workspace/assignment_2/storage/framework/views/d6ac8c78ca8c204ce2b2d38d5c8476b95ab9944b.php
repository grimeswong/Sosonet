<?php $__env->startSection('title'); ?>
    Update Post Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" >
        
        <!-- Form -->
        <div class="col-sm-offset-2 col-sm-8 form-border">
            <form method="post" action="/post/<?php echo e($post->id); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>    <!-- use the method put that using the hidden method put -->
                <div class="name"><h2>Update Post Form</h2></div>
                
                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                <div class="form-group message"><label>User Name <?php echo e(Auth::user()->fullname); ?> </label><br>
                    <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
                </div>
                
                <div class="name"><label>Title: </label><br>
                    <?php if(count($errors)>0): ?>
                        <input type="text" name="title" value="<?php echo e(old('title')); ?>"><span class="alert"><?php echo e($errors->first('title')); ?></span>
                    <?php else: ?>
                        <input type="text" name="title" value="<?php echo e($post->title); ?>">
                    <?php endif; ?>
                </div>
                <div class="message"><label>Message: </label><br>
                    <?php if(count($errors)>0): ?>
                        <textarea id="messagetextarea" name="message" rows="4"><?php echo e(old('message')); ?></textarea><span class="alert"><?php echo e($errors->first('message')); ?></span>
                    <?php else: ?>
                        <textarea id="messagetextarea" name="message" rows="4"><?php echo e($post->message); ?></textarea>
                    <?php endif; ?>
                </div>
                
                <div class="form-group message">
                  <label for="privacy">Privacy</label>
                  <select name="privacy" class="form-control">
                    <?php if(count($errors)>0): ?>
                        <?php if(old('privacy') == "public"): ?>
                            <option value="public" selected>Public</option>
                            <option value="friends">Friends</option>
                            <option value="private">Private</option>
                        <?php elseif(old('privacy') == "friends"): ?>
                            <option value="public">Public</option>
                            <option value="friends" selected>Friends</option>
                            <option value="private">Private</option>
                        <?php else: ?>                
                            <option value="public" selected>Public</option>
                            <option value="friends">Friends</option>
                            <option value="private" selected>Private</option>
                        <?php endif; ?>
                    <?php else: ?>      
                        <?php if($post->privacy == "public"): ?>
                            <option value="public" selected>Public</option>
                            <option value="friends">Friends</option>
                            <option value="private">Private</option>
                        <?php elseif($post->privacy == "friends"): ?>
                            <option value="public">Public</option>
                            <option value="friends" selected>Friends</option>
                            <option value="private">Private</option>
                        <?php else: ?>                
                            <option value="public" selected>Public</option>
                            <option value="friends">Friends</option>
                            <option value="private" selected>Private</option>
                        <?php endif; ?>
                    <?php endif; ?>
                  </select>
                </div>
                
                <div class="message">
                    <button class="btn btn-success" type="submit">Save</button>
                    <a class="btn btn-default" href="<?php echo e(url("/")); ?>">Cancel</a>
                </div>
                
            </form>
        </div>
    </div> <!-- end of row maincontent -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>