<?php $__env->startSection('title'); ?>
    Home Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        
        <!-- Create Post Form -->
        <div class="col-sm-4 form-border">
            <form method="post" action="/post">
                <?php echo e(csrf_field()); ?>

                <div class="name form-group"><h2>Create Post Form</h2></div>
                
                <?php if(Auth::check()): ?> <!-- make sure user has logged in to get user name -->
                <div class="name"><label>Current User: <?php echo e(Auth::user()->fullname); ?></label><br>
                  <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
                </div>
                <?php endif; ?>

                <div class="name"><label>Title: </label><br>
                    <?php if(count($errors)>0): ?>
                        <input type="text" name="title" value="<?php echo e(old('title')); ?>"><span class="alert"><?php echo e($errors->first('title')); ?></span>
                    <?php else: ?>
                        <input type="text" name="title" placeholder="Enter a title">
                    <?php endif; ?>
                </div>
                <div class="message"><label>Message: </label><br>
                    <?php if(count($errors)>0): ?>
                        <textarea id="messagetextarea" name="message" rows="4" ><?php echo e(old('message')); ?></textarea><span class="alert"><?php echo e($errors->first('message')); ?></span>
                    <?php else: ?>
                        <textarea id="messagetextarea" name="message" rows="4" placeholder="Enter new message"></textarea>
                    <?php endif; ?>
                </div>
                <div class="form-group message">
                  <label for="privacy">Privacy</label>
                        <select name="privacy" class="form-control">
                    <?php if(count($errors)>0): ?>
                        <?php if(old('privacy') == "public"): ?>
                            <option value="public" selected>Public</option>
                            <option value="friends">Friends</option>
                            <option value="private">Private</option>
                        <?php elseif(old('privacy') == "friends"): ?>
                            <option value="public">Public</option>
                            <option value="friends" selected>Friends</option>
                            <option value="private">Private</option>
                        <?php else: ?>                
                            <option value="public" selected>Public</option>
                            <option value="friends">Friends</option>
                            <option value="private" selected>Private</option>
                        <?php endif; ?>
                    <?php else: ?>      
                            <option value="public" selected>Public</option>
                            <option value="friends">Friends</option>
                            <option value="private">Private</option>
                    <?php endif; ?>
                  </select>
                </div>
                <div class="message">
                    <button class="btn btn-warning" type="submit">Create new post</button>
                </div>
            </form>
        </div>
         <!-- End Form -->      
                
        <!-- Post Listing -->
        <div class="col-sm-8">
            
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="panel panel-primary">
                <div class="panel-heading clearfix">
                    <img class="avatar" src= "/<?php echo e($post->user->image); ?>" alt="Image's not available"></img>
                    <a href="user/<?php echo e($post->user_id); ?>"><span class="username"><?php echo e($post->user->fullname); ?></span></a>
                    <?php if(Auth::id() == $post->user_id): ?>
                    <form method="POST" action="/post/<?php echo e($post->id); ?>"> <!-- Delete Button -->
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>  <!-- we use the method delete that using the hidden method -->
                        <button class="btn btn-danger btn-margin pull-right" type="submit">Delete</button>
                    </form>
                    <a class="btn btn-success btn-margin pull-right" href="post/<?php echo e($post->id); ?>/edit">Edit</a>
                    <?php endif; ?>
                </div>
                
                <div class="panel-body">
                    <h4><?php echo e($post->title); ?></h4>
                    <p><?php echo e($post->message); ?></p>
                    <!-- Team show Privacy -->
                    <p class="pull-left">Privacy Level: <?php echo e($post->privacy); ?></p>
                    <a class="btn btn-primary pull-right" href="<?php echo e(url("comment/$post->id")); ?>">
                        View Comment
                        <?php $__currentLoopData = $commentsCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($commentCount->id == $post->id): ?>
                                <span class="badge"><?php echo e($commentCount->comments_count); ?></span>
                            <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </a>
                </div>
                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                <h3 class="error-middle">No post found</h3>
            <?php endif; ?>
            
        </div>  <!-- end post panel -->
    </div> <!-- end of row maincontent-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>