<?php $__env->startSection('title'); ?>
    Home Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4">
        <h2>Search for users</h2>
          <form class="input-group navbar-form" style="max-width: 250px" id="search-form" method=get action="search">
            <input class="form-control" name="name" placeholder="Search Friend..." />
            <span class="input-group-btn">
            <button type="submit" class="btn btn-default">
                <span class="glyphicon glyphicon-search">
                    <span class="sr-only">Search</span>
                </span>
            </button>
            </span>
        </form>
    </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>