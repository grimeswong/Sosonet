<?php $__env->startSection('title'); ?>
    Home Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-offset-3 col-sm-6 form-border">
        <form method="post" action="/user">
            <?php echo e(csrf_field()); ?>

            <div class="name form-group"><h2>Create User Form</h2></div>
            <div class="name"><label>Full Name </label><br>
                <?php if(count($errors)>0): ?>
                    <input type="text" name="fullname" value="<?php echo e(old('email')); ?>"><span class="alert"><?php echo e($errors->first('fullname')); ?></span>
                <?php else: ?>
                    <input type="text" name="fullname" placeholder="Enter a full name">
                <?php endif; ?>
            </div>
            <div class="name form-group"><label>Password</label><br>
                <?php if(count($errors)>0): ?>
                    <input type="password" name="password" ><span class="alert"><?php echo e($errors->first('password')); ?></span>
                <?php else: ?>
                    <input type="password" name="password" placeholder="Enter a password">
                <?php endif; ?>
            </div>
            <div class="name form-group"><label>Confirm Password</label><br>
                <?php if(count($errors)>0): ?>
                    <input type="password" name="password_confirmation"><span class="alert"><?php echo e($errors->first('email')); ?></span>
                <?php else: ?>
                    <input type="password" name="password_confirmation" placeholder="Confirm password">
                <?php endif; ?>
            </div>
            <div class="name form-group"><label>Email</label><br>
                <?php if(count($errors)>0): ?>
                    <input type="text" name="email" value="<?php echo e(old('email')); ?>"><span class="alert"><?php echo e($errors->first('email')); ?></span>
                <?php else: ?>
                    <input type="text" name="email" placeholder="Enter an email">
                <?php endif; ?>
            </div>
            <div class="name form-group"><label>DOB</label><br>
                <?php if(count($errors)>0): ?>
                    <input type="text" name="DOB" value="<?php echo e(old('DOB')); ?>"><span class="alert"><?php echo e($errors->first('DOB')); ?></span>
                <?php else: ?>
                    <input type="text" name="DOB" placeholder="yyyy/mm/dd">
                <?php endif; ?>
            </div>
            <div class="name form-group"><label>Upload Image File</label><br>
                <?php if(count($errors)>0): ?>
                    <input type="text" name="image" value="<?php echo e(old('image')); ?>"><span class="alert"><?php echo e($errors->first('image')); ?></span>
                <?php else: ?>
                    <input type="text" name="image" placeholder="Enter a path of image">
                <?php endif; ?>
            </div>
            <div class="message">
                <button class="btn btn-warning" type="submit">Create new user</button>
                <a class="btn btn-default" href="<?php echo e(url("user")); ?>">Cancel</a>
            </div>
        </form>
            <a class="name btn btn-success" href="<?php echo e(url("post")); ?>">Return to home page</a>
        
        
    </div>
     <!-- End Form -->      
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>