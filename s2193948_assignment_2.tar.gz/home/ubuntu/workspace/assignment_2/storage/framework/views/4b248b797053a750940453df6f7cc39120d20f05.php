<?php $__env->startSection('title'); ?>
    User Profile Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-sm-offset-2 col-sm-8">
            <h2 col>User Profile</h2>
            <div class="panel panel-primary">
                <div class="panel-heading clearfix">
                        <img class="avatar" src= "/<?php echo e($user->image); ?>" alt="Image's not available"></img>
                        <span class="username"><?php echo e($user->fullname); ?></span>
                        <span>Age: <?php echo e($age); ?></span>
                        <?php if(Auth::check()): ?> <!-- Check the user whether logged in -->
                            <?php $__currentLoopData = $friendships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friendship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--<h2>Friendship id<?php echo e($friendship->id); ?> and auth id<?php echo e(Auth::id()); ?> and user id <?php echo e($user->id); ?></h2>-->
                            
                                <?php if($friendship->id == Auth::id()): ?> <!-- if user is not current user and not is friend of user yet -->
                                <form method="post" action="/friend/<?php echo e($user->id); ?>">
                                    <?php echo e(csrf_field()); ?>                                    
                                    <?php echo e(method_field('DELETE')); ?>  <!-- we use the method delete that using the hidden method -->
                                    <button class="btn btn-danger pull-right" type="submit">Unfriend</button>
                                </form>
                                
                                <?php elseif($friendship->id != $user->id && $user->id != Auth::id()): ?>
                                <!--<form method="post" action="/addFriend">-->
                                <!--    <input type="hidden" name="user_id">-->
                                <!--    <input type="hidden" name="friend_user_id">-->
                                <!--    <button class="btn btn-success pull-right" type="submit">Add Friend</button>-->
                                <!--</form>-->
                                
                                <?php elseif($user->id != Auth::id()): ?>    <!-- user browse his own profile
                                    <!-- do nothing -->
                                <?php else: ?>
                             
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        <?php endif; ?>
                </div>
            </div>
            
            
            
            <?php if(count($posts) > 0): ?>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="panel panel-primary">
                            <div class="panel-heading clearfix">
                                <h4><?php echo e($post->title); ?></h4>
                            </div>
                            <div class="panel-body">
                                <p><?php echo e($post->message); ?></p>
                                <!-- Team show Privacy -->
                                <p class="pull-left">Privacy Level: <?php echo e($post->privacy); ?></p>
                                <a class="btn btn-primary pull-right" href="<?php echo e(url("comment/$post->id")); ?>">
                                View Comment
                                <?php $__currentLoopData = $commentsCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($commentCount->id == $post->id): ?>
                                        <span class="badge"><?php echo e($commentCount->comments_count); ?></span>
                                    <?php endif; ?>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </a>
                            </div>    
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h2>No Post to Show</h2>
                <?php endif; ?>
            <?php endif; ?>
            
        </div>  <!-- end post panel -->    
        
       
        
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>