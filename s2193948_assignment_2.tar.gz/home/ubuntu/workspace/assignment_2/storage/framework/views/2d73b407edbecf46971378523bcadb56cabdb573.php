<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="<?php echo e(secure_asset('css/style.css')); ?>">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">    <!-- Bootstrap core css (cdn) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>    <!-- jQuery linking cdn files -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> <!-- Bootstrap linking cdn files -->
    </head>
    
    <body>
        <!-- navigation bar -->
        <nav class="navbar navbar-inverse"> <!-- inverse=black theme, fixed-top=nav fix on top -->
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar"> <!-- collapse button -->
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span> 
                    </button>
                    <a class="navbar-brand"  href="/">So Show Net</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav nav-pills navbar-nav navbar-left">  <!-- nav style = pills, right aligned -->
                        <li role="presentation"><a href="<?php echo e(url("/")); ?>">Home</a></li>
                        <li role="presentation"><a href="<?php echo e(url("user")); ?>">Search Users</a></li>
                        <?php if(Auth::check()): ?>
                            <li role="presentation"><a href="<?php echo e(url("friend")); ?>">Friends</a></li>
                        <?php endif; ?>
                        <li role="presentation"><a href="<?php echo e(url("documentation")); ?>">Documentation</a></li>
                        <li role="presentation"><a href="<?php echo e(url("erdiagram")); ?>">ER Diagram</a></li>
                        <form class="input-group navbar-form" style="max-width: 250px" id="search-form" method="get" action="/search">
                            <input class="form-control" name="name" placeholder="Search Users..." />
                            <span class="input-group-btn">
                            <button type="submit" class="btn btn-default btn-searchbar">
                                <span class="glyphicon glyphicon-search">
                                    <span class="sr-only">Search</span>
                                </span>
                            </button>
                            </span>
                        </form>
                    </ul>
                    <!-- right navigation bar -->
                    <ul class="nav nav-pills navbar-nav navbar-right">
                         <!--<li role="presentation"><a href="<?php echo e(url("user/create")); ?>">Create A User</a></li>-->
                        <?php if(Auth::guest()): ?>
                            <li role="presentation"><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li role="presentation"><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li role="presentation"><a href="/user/<?php echo e(Auth::user()->id); ?>/edit"> Welcome! <?php echo e(Auth::user()->fullname); ?></a></li>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    Logout
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                         <?php endif; ?>
                    </ul>
                </div>
            </div> <!-- end navbar container -->
        </nav> <!-- end navbar -->
        
        <!-- main contend insert by child -->
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?> 
        </div>
    </body>
</htmlasdf>